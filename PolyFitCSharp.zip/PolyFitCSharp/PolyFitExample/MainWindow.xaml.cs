﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Research.DynamicDataDisplay;
using Microsoft.Research.DynamicDataDisplay.DataSources;
using Microsoft.Research.DynamicDataDisplay.PointMarkers;
using ViliPetek.LinearAlgebra;

namespace PolyFitExample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ObservableCollection<Point> _dataSeries;
        private ObservableCollection<Point> _fittedSeries;

        public MainWindow()
        {
            InitializeComponent();
            InitializeGraphs();
            GraphData();
        }

        private void InitializeGraphs()
        {
            // create the storage for the series
            _dataSeries = new ObservableCollection<Point>();
            _fittedSeries = new ObservableCollection<Point>();

            // create the series
            chartPlotter.AddLineGraph(_dataSeries.AsDataSource(), new Pen(Brushes.Blue, 1),
                new CircleElementPointMarker { Size = 3, Brush = Brushes.Blue, Fill = Brushes.Blue },
                new PenDescription("Data"));
            chartPlotter.AddLineGraph(_fittedSeries.AsDataSource(), new Pen(Brushes.Red, 3), new PenDescription("PolyFit"));

            // hide the standard legend
            chartPlotter.LegendVisibility = System.Windows.Visibility.Hidden;
            chartPlotter.NewLegendVisible = false;
        }

        private void GraphData()
        {
            const int DataSize = 1024;
            
            Random rand = new Random();
            double[] x = new double[DataSize];
            double[] y = new double[DataSize];

            // generate the data
            for (int i = 0; i < DataSize;i++ )
            {
                x[i] = i;
                y[i] = Math.Sin((double)i / 1024.0 * Math.PI * 2) + (rand.NextDouble() - 0.5);
            }
            
            // fit the data
            var polyfit = new PolyFit(x, y, (int)orderField.Value);
            var fitted = polyfit.Fit(x);
            
            // plot the data
            _dataSeries.SetXY(x, y);
            _fittedSeries.SetXY(x, fitted);
        }

        private void graphButton_Click(object sender, RoutedEventArgs e)
        {
            GraphData();
        }
    }
}
