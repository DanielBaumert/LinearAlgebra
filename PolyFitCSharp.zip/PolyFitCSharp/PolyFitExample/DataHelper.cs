﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PolyFitExample
{
    public static class DataHelper
    {
        /// <summary>
        /// Set the data to an ObservableCollection from two arrays representing x and y coordinates.
        /// </summary>
        /// <param name="self">ObservableCollection</param>
        /// <param name="x">x value array</param>
        /// <param name="y">y value array</param>
        public static void SetXY(this ObservableCollection<Point> self, double[] x, double[] y)
        {
            if (x.Length != y.Length)
            {
                throw new ArgumentException("x and y counts need to match");
            }
            self.Clear();
            for (int i = 0; i < x.Length; i++)
            {
                self.Add(new Point(x[i], y[i]));
            }
        }
    }
}
